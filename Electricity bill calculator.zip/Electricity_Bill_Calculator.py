import tkinter as tk
from tkinter import messagebox
import csv
from datetime import datetime
import os

csv_file='Electricity Bill.csv4'

def calculate_bill():
   try:
    customer_name=entry_name.get().strip()
    consumed_units=int(entry_units.get())

    if not customer_name:
        raise ValueError("Name should be filled")
    if consumed_units < 0:
        raise ValueError("units cannot be in negative")
    if consumed_units<=100:
        bill_amount=consumed_units*1.5
    elif consumed_units<=200:
        bill_amount=(100*1.5)+((consumed_units -100)*2.5)
    elif consumed_units<=300:
        bill_amount=(100*1.5)+(100*2.5)+((consumed_units-200)*4)
    else:
        bill_amount=(100*1.5)+(100*2.5) +(100*4)+((consumed_units-300)*6)

    bill_amount=round(bill_amount,2)
    timestamp=datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
    result_label.config(text=f"{customer_name},your bill is rupees :{bill_amount:.2f}") 
    
    with open(csv_file,mode="a", newline='')as file:
        writer = csv.writer(file)
        if os.path.getsize(csv_file)==0:
            writer.writerow(["Date & time","customer Name","Units","Amount"])
        writer.writerow([timestamp,customer_name,consumed_units,bill_amount])

    messagebox.showinfo("Success","Bill Saved successfully!")


   except ValueError as error:
    messagebox.showerror("input error",str(error))

def view_bills():
    if not os.path.exists(csv_file) or os.path.getsize(csv_file)==0:
      messagebox.showinfo("no record found","no bill records found.")
      return
    view_window=tk.Toplevel(root)
    view_window.title("Saved Bill Records")
    view_window.geometry("450x350")

    text_area=tk.Text(view_window)
    text_area.pack(expand=True, fill="both")

    with open(csv_file,"r") as file:
      for line in file:
       text_area.insert(tk.END,line)

def update_record(customer_name,new_units):
  try:
    new_units= int(new_units)
    if new_units < 0:
      raise ValueError("units cannot be negative")
  except ValueError as error:
    messagebox.showinfo("Input errror",str(error))
    return
  if not os.path.exists(csv_file):
    messagebox.showinfo("info","no records found  to upade")
    return
  updated_data=[]
  record_found=False

  with open(csv_file,"r") as file:
    reader=csv.reader(file)
    all_rows=list(reader)

    if all_rows:
      updated_data.append(all_rows[0])

      for row in all_rows[1:]:
        if row[1].lower()==customer_name.lower():
          record_found=True
          if new_units<=100:
            new_amount=new_units*1.5
          elif new_units<=200:
            new_amount=(100*1.5)+(new_units-100)*2.5
          elif new_units<=300:
            new_amount=(100*1.5)+(100*2.5)+(new_units-200)*4
          else:
            new_amount=(100*1.5)+(100*2.5)+(300*4)+(new_units-300)*6
          new_amount=round(new_amount,2)

          row[2]=str(new_units)
          row[3]=str(new_amount)
        updated_data.append(row)
  if not record_found:
    messagebox.showinfo("not found","customer name {customer_name}is not found")
    return

  with open(csv_file,"w",newline='')as file:
    writer=csv.writer(file)
    writer.writerows(updated_data)

  messagebox.showinfo("success",f"record updated for {customer_name}")

def edit_bill_popup():
  popup=tk.Toplevel(root)
  popup.title("Edit Bill Record")
  popup.geometry("300x200")

  tk.Label(popup,text="Enter customer Name:").pack(pady=5)
  name_input=tk.Entry(popup)
  name_input.pack(pady=5)

  tk.Label(popup,text="enter new units consumed").pack(pady=5)
  units_input=tk.Entry(popup)
  units_input.pack(pady=5)

  def updated_button_clicked():
    name=name_input.get().strip()
    units=units_input.get().strip()

    if not name or not units:
      messagebox.showinfo("Error","Please fill in all fields")
      return
    update_record(name,units)
    popup.destroy()

  tk.Button(popup,text="updated",command=updated_button_clicked,bg="magenta",fg="white").pack(pady=15)
def delete_records(customer_name):
  if not os.path.exists(csv_file):
    messagebox.showinfo("Info","no recordfound")
    return

  deleted=False
  updated_data=[]

  with open(csv_file,"r") as file:
    reader =csv.reader(file)
    rows= list(reader)

    if rows:
      updated_data.append(rows[0])
      for row in rows[1:]:
        if  row[1].lower()!=customer_name.lower():
          updated_data.append(row)

        else:
          deleted=True


  if not deleted:
    messagebox.showinfo("not found",f"no record found {customer_name}")
    return

  with open(csv_file,"w",newline='')as file:
    writer=csv.writer(file)
    writer.writerows(updated_data)

  messagebox.showinfo("Success",f"record {customer_name} is deleted")

def delete_bill_popup():
  popup=tk.Toplevel(root)
  popup.title("Delete Bill Record")
  popup.geometry("300x200")

  tk.Label(popup,text="enter the customer name to delete").pack(pady=10)
  name_entry=tk.Entry(popup)
  name_entry.pack(pady=10)

  def confirm_delete():
    name =name_entry.get().strip()
    if not name:
      messagebox.showinfo("Error","Please enter a name")
      return
    delete_records(name)
    popup.destroy()


  tk.Button(popup,text="delete",command=confirm_delete,bg="red",fg="white").pack(pady=15)


root=tk.Tk()
root.title("Electricity Bill Calculator")
root.geometry("500x600")
root.config(bg="Lavender")

tk.Label(root,text="Electricity bill Calculator",font=("Script light",16,"bold"),bg="lightblue").pack(pady=15)
        
tk.Label(root,text="Customer Name",bg="lightblue").pack()
entry_name=tk.Entry(root)
entry_name.pack(pady=15)

tk.Label(root,text="Units Consumed",bg="lightblue").pack()
entry_units=tk.Entry(root)
entry_units.pack(pady=15)

tk.Button(root,text="Caluculated Bill",command=calculate_bill,bg="green",fg="white").pack(pady=10)
tk.Button(root,text="View Saved Bills",command=view_bills,bg="blue",fg="white").pack(pady=10)
tk.Button(root,text="Edit Bill Record",command=edit_bill_popup,bg="purple",fg="white").pack(pady=10)
tk.Button(root,text="Delete Bill Record",command=delete_bill_popup,bg="pink",fg="white").pack(pady=10)

result_label=tk.Label(root,text="",font=("roboto",12),bg="light blue",fg="black")
result_label.pack(pady=20)

root.mainloop()
        
